import ts from 'typescript-eslint';
export default ts.config(...ts.configs.recommended, {
  ignores: [
    'dist/**',
    'node_modules/**',
    'playwright-report/**',
    'test-results/**',
  ],
});
